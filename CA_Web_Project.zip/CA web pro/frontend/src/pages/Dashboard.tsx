import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { ArrowUpRight, ArrowDownRight, Users, Bell, Clock, FileText, TrendingUp, AlertCircle, Calendar, IndianRupee, Activity, Target, Upload, Shield } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import API_BASE, { apiFetch } from '../config/api';
import './Dashboard.css';

const COLORS = ['#5e5ce6', '#32d74b', '#ff9f0a', '#ff453a'];

const revenueData = [
  { month: 'Apr', rev: 45.2 }, { month: 'May', rev: 52.8 }, { month: 'Jun', rev: 48.5 },
  { month: 'Jul', rev: 61.2 }, { month: 'Aug', rev: 58.9 }, { month: 'Sep', rev: 65.4 },
];

const serviceData = [
  { name: 'Income Tax', value: 400 },
  { name: 'GST Filing', value: 300 },
  { name: 'Audit', value: 200 },
  { name: 'Advisory', value: 100 },
];

const activities = [
  { text: 'ITR-1 Filed for Amit Shah', time: '12 mins ago', icon: FileText, color: '#32d74b' },
  { text: 'Payment received: ₹15,000', time: '45 mins ago', icon: IndianRupee, color: '#bf5af2' },
  { text: 'New client registration: RK Exports', time: '2 hours ago', icon: Users, color: '#5e5ce6' },
  { text: 'Reminder sent: GST Deadline', time: '5 hours ago', icon: Bell, color: '#ff9f0a' },
];

const deadlines = [
  { title: 'GST GSTR-3B Filing', date: 'Oct 20, 2026', urgency: 'high' },
  { title: 'TDS Payment Q3', date: 'Oct 07, 2026', urgency: 'medium' },
  { title: 'MCA Annual Filing', date: 'Oct 30, 2026', urgency: 'low' },
];

const quickActions = [
  { label: 'Add Client', icon: Users, gradient: 'linear-gradient(135deg, #5e5ce6, #818cf8)' },
  { label: 'Upload Doc', icon: Upload, gradient: 'linear-gradient(135deg, #32d74b, #63e6be)' },
  { label: 'Create Bill', icon: IndianRupee, gradient: 'linear-gradient(135deg, #ff9f0a, #ffb340)' },
  { label: 'Compliance', icon: Shield, gradient: 'linear-gradient(135deg, #ff453a, #ff6961)' },
];

export default function Dashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState({ totalClients: 156, activeReturns: 42, pendingTasks: 8, revenue: 65.4 });
  const [greeting, setGreeting] = useState('');

  useEffect(() => {
    const h = new Date().getHours();
    setGreeting(h < 12 ? 'Good Morning' : h < 17 ? 'Good Afternoon' : 'Good Evening');
  }, []);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await apiFetch(`${API_BASE}/api/dashboard/stats`, {
          headers: { 'Authorization': `Bearer ${user?.token}` }
        });
        if (res.ok) {
          const data = await res.json();
          setStats(prev => ({ ...prev, ...data }));
        }
      } catch (err) { /* use fallback data */ }
    };
    if (user?.token) fetchStats();
  }, [user]);

  const statCards = [
    { label: 'Total Clients', value: stats.totalClients, icon: Users, trend: '+12%', positive: true, gradient: 'linear-gradient(135deg, hsla(246, 80%, 60%, 0.12), hsla(246, 80%, 60%, 0.04))' },
    { label: 'Active Returns', value: stats.activeReturns, icon: FileText, trend: '+8', positive: true, gradient: 'linear-gradient(135deg, hsla(145, 65%, 52%, 0.12), hsla(145, 65%, 52%, 0.04))' },
    { label: 'Pending Tasks', value: stats.pendingTasks, icon: Clock, trend: '-3', positive: true, gradient: 'linear-gradient(135deg, hsla(35, 92%, 48%, 0.12), hsla(35, 92%, 48%, 0.04))' },
    { label: 'Revenue (₹L)', value: stats.revenue, icon: IndianRupee, trend: '+18.2%', positive: true, gradient: 'linear-gradient(135deg, hsla(280, 67%, 64%, 0.12), hsla(280, 67%, 64%, 0.04))' },
  ];

  return (
    <div className="dashboard-elite">
      {/* Header */}
      <header className="dash-header">
        <div className="dash-greeting">
          <motion.h1 initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
            {greeting}, <span className="text-gradient">{user?.name?.split(' ')[0] || 'User'}</span> 👋
          </motion.h1>
          <p className="text-muted">Here's what's happening with your practice today.</p>
        </div>
        <div className="dash-header-actions">
          <div className="dash-date">
            <Calendar size={16} />
            {new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
          </div>
        </div>
      </header>

      {/* Quick Actions */}
      <div className="quick-actions">
        {quickActions.map((qa, i) => (
          <motion.button key={qa.label} className="quick-action-btn" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}>
            <div className="qa-icon" style={{ background: qa.gradient }}><qa.icon size={18} /></div>
            {qa.label}
          </motion.button>
        ))}
      </div>

      {/* Stat Cards */}
      <div className="stat-grid">
        {statCards.map((s, i) => (
          <motion.div key={s.label} className="stat-card" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}
            style={{ background: s.gradient }}>
            <div className="stat-card-header">
              <span className="stat-label">{s.label}</span>
              <div className={`stat-trend ${s.positive ? 'up' : 'down'}`}>
                {s.positive ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />} {s.trend}
              </div>
            </div>
            <div className="stat-value">{typeof s.value === 'number' && s.value > 100 ? s.value.toLocaleString() : s.value}</div>
            <div className="stat-icon-bg"><s.icon size={40} /></div>
          </motion.div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="dash-charts-row">
        <motion.div className="dash-chart-card card" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}>
          <div className="chart-card-header">
            <h3><Activity size={18} /> Revenue Trend</h3>
            <span className="chart-badge">FY 2025-26</span>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={revenueData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="dashGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#5e5ce6" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#5e5ce6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="month" stroke="var(--text-muted)" fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke="var(--text-muted)" fontSize={11} tickLine={false} axisLine={false} tickFormatter={v => `₹${v}L`} />
              <Tooltip contentStyle={{ backgroundColor: 'var(--bg-surface)', border: '1px solid var(--border-color)', borderRadius: '8px', fontSize: '0.85rem' }} formatter={(v: any) => [`₹${v}L`, 'Revenue']} />
              <Area type="monotone" dataKey="rev" stroke="#5e5ce6" strokeWidth={2.5} fill="url(#dashGrad)" dot={{ fill: '#5e5ce6', r: 3 }} activeDot={{ r: 5, fill: '#5e5ce6' }} />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div className="dash-chart-card card" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}>
          <div className="chart-card-header">
            <h3><TrendingUp size={18} /> Service Mix</h3>
            <span className="chart-badge">This Quarter</span>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie data={serviceData} innerRadius={55} outerRadius={90} paddingAngle={4} dataKey="value" fontSize={11}>
                {serviceData.map((_entry, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: 'var(--bg-surface)', border: '1px solid var(--border-color)', borderRadius: '8px', fontSize: '0.85rem' }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="pie-legend">
            {serviceData.map((s, i) => (
              <span key={s.name}><span className="legend-dot" style={{ background: COLORS[i] }} />{s.name}</span>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Bottom Row */}
      <div className="dash-bottom-row dash-bottom-3">
        {/* Activity Feed */}
        <motion.div className="dash-panel card" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}>
          <h3><Bell size={18} /> Recent Activity</h3>
          <div className="activity-feed">
            {activities.map((a, i) => (
              <motion.div key={i} className="activity-item" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.5 + i * 0.08 }}>
                <div className="activity-icon" style={{ background: `${a.color}15`, color: a.color }}><a.icon size={16} /></div>
                <div className="activity-text">
                  <span>{a.text}</span>
                  <small className="text-muted">{a.time}</small>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Financial Health Score */}
        <motion.div className="dash-panel card health-score-panel" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.55 }}>
          <h3><Target size={18} /> Financial Health</h3>
          <div className="health-gauge">
            <svg viewBox="0 0 120 120" className="gauge-svg">
              <circle cx="60" cy="60" r="50" fill="none" stroke="var(--border-color)" strokeWidth="8" />
              <motion.circle cx="60" cy="60" r="50" fill="none" stroke="url(#healthGrad)" strokeWidth="8"
                strokeLinecap="round" strokeDasharray="314" initial={{ strokeDashoffset: 314 }}
                animate={{ strokeDashoffset: 314 - (314 * 0.87) }} transition={{ delay: 0.8, duration: 1.5, ease: 'easeOut' }}
                transform="rotate(-90 60 60)" />
              <defs>
                <linearGradient id="healthGrad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#32d74b" />
                  <stop offset="100%" stopColor="#5e5ce6" />
                </linearGradient>
              </defs>
            </svg>
            <div className="gauge-center">
              <motion.span className="gauge-value" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.2 }}>87</motion.span>
              <span className="gauge-label">/ 100</span>
            </div>
          </div>
          <div className="health-items">
            {[
              { label: 'Tax Compliance', score: 98, color: '#32d74b' },
              { label: 'Filing Timeliness', score: 85, color: '#5e5ce6' },
              { label: 'Debt Ratio', score: 78, color: '#ff9f0a' },
              { label: 'Growth Rate', score: 92, color: '#bf5af2' },
            ].map((h, i) => (
              <div key={h.label} className="health-row">
                <span>{h.label}</span>
                <div className="health-bar-track">
                  <motion.div className="health-bar-fill" style={{ background: h.color }}
                    initial={{ width: 0 }} animate={{ width: `${h.score}%` }}
                    transition={{ delay: 0.9 + i * 0.1, duration: 0.8 }} />
                </div>
                <span className="health-score-val">{h.score}%</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Deadlines */}
        <motion.div className="dash-panel card" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }}>
          <h3><AlertCircle size={18} /> Upcoming Deadlines</h3>
          <div className="deadline-list">
            {deadlines.map((d, i) => (
              <motion.div key={i} className="deadline-item" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.6 + i * 0.08 }}>
                <div className={`deadline-urgency ${d.urgency}`} />
                <div className="deadline-text">
                  <span>{d.title}</span>
                  <small className="text-muted">{d.date}</small>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
